---
name: code-review-best-practices
description: Calibrate severity and write review comments that a developer can act on. Use when reviewing a diff or file and deciding how serious a finding is, or how to phrase it.
---

# Code Review Best Practices

## Severity calibration

Ask "what happens in production if this ships?"

| Severity | Test |
|---|---|
| critical | Exploitable now, or causes data loss / auth bypass. Blocks the merge. |
| high | Will break in normal use, or a vulnerability needing one more precondition. |
| medium | Real defect, limited blast radius, or a problem only under load. |
| low | Minor correctness or clarity cost. Safe to defer. |
| info | Observation. No action required. |

Do not inflate. A review where everything is "high" tells the author nothing
about what to fix first.

## What makes a finding useful

1. **Anchored** - a real line number in the current version of the file.
2. **Causal** - says what goes wrong, not just what looks unusual.
3. **Actionable** - the suggestion is a change, not a direction.
4. **Scoped** - one problem per finding.

## What to leave out

- Anything a formatter or linter fixes automatically.
- Style preferences the surrounding code does not already follow.
- Speculation about code you have not read ("this might be called with null").
  Check the call sites first, then say it definitely.
- Rewrites of code the diff did not touch, unless the diff makes it wrong.

## Phrasing

Describe the code, not the author. "This interpolates unvalidated input into a
SQL string" - not "you forgot to sanitize". State the fix in the imperative:
"Use a parameterized query."
