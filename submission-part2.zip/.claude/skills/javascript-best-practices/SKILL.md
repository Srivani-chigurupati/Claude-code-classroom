---
name: javascript-best-practices
description: JavaScript and TypeScript correctness and idiom checklist - async mistakes, equality, error handling, typing, performance. Use when reviewing JS/TS source files.
---

# JavaScript / TypeScript Best Practices

## Async correctness

- `await` inside a `for` loop over independent work -> `Promise.all`.
- A promise created and never awaited or `.catch`ed (unhandled rejection).
- `async` callback passed to `forEach` - the results are dropped; use
  `for...of` with `await`, or `map` + `Promise.all`.
- `try/catch` around code whose only async call is not awaited - the catch
  never fires.
- Missing `await` before returning inside `try` when the `catch` matters.

## Errors

- `catch (e) {}` or `catch` that only logs and continues with invalid state.
- Throwing a string or plain object instead of an `Error`.
- Losing the cause: rethrowing a new error without `{ cause: e }` or the
  original message.

## Equality and coercion

- `==`/`!=` across types; `== null` is the one acceptable use.
- Truthiness checks on values where `0` or `''` is valid -> use `?? `/
  explicit `!== undefined`.
- `parseInt` without a radix; `Number.isNaN` rather than `isNaN`.

## Declarations and scope

- `var` -> `const`/`let`.
- Reassigned-once bindings that should be `const`.
- Closures capturing a loop variable declared with `var`.
- Mutating a parameter, or a default that is a shared object/array literal.

## Types (TypeScript)

- `any` where a real type is available; prefer `unknown` at boundaries.
- Type assertions (`as`) standing in for validation of external data - validate
  with a schema instead.
- Non-null assertions (`!`) on values that can genuinely be null.
- Optional fields that should be a discriminated union.

## Performance

- Regex or large literal rebuilt inside a hot loop -> hoist it.
- Repeated `array.find`/`includes` inside a loop over another array -> build a
  `Map`/`Set` once (O(n²) -> O(n)).
- Array spread accumulation in a reduce (`[...acc, x]`) -> `push`.
- Unbounded caches or event listeners never removed (memory leak).

## Hygiene

- Unused variables, imports and parameters.
- `console.log` left in library or server code -> use the logger.
- Dead code and commented-out blocks.
- Duplicated logic that already exists elsewhere in the module.
