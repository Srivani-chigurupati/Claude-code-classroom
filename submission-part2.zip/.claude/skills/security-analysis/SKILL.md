---
name: security-analysis
description: Checklist for finding security vulnerabilities in application source code - injection, secrets, authz, unsafe deserialization, crypto. Use when reviewing code for security issues.
---

# Security Analysis

Work the checklist. For each hit, confirm the tainted value really reaches the
sink before reporting it.

## Injection

- SQL/NoSQL built by string concatenation or template literal with any
  request-derived value -> parameterize.
- Shell: `exec`, `execSync`, `spawn` with `shell: true` and interpolated input
  -> use `execFile`/`spawn` with an argument array.
- HTML: `innerHTML`, `outerHTML`, `document.write`, `dangerouslySetInnerHTML`,
  unescaped template output -> escape or sanitize.
- Code: `eval`, `new Function`, `setTimeout` with a string body.
- Path traversal: user input reaching `fs`/`path.join` without normalizing and
  checking the result stays under the intended root.
- Prototype pollution: recursive merge/clone or `obj[key] = value` where `key`
  is user-controlled and `__proto__`/`constructor` is not rejected.

## Secrets and configuration

- Hardcoded API keys, tokens, passwords, private keys, connection strings.
- Secrets in logs, error messages, or URLs (query strings get logged).
- `.env` files or credentials committed to the repository.

## Authentication and authorization

- A route or handler that reads/writes another user's data without checking
  ownership (IDOR).
- Auth check present on the happy path but skipped on an early return.
- Tokens compared with `==` instead of a constant-time compare.
- Session or JWT with no expiry, or verified with `algorithms: ['none']` /
  no algorithm pinning.

## Data handling

- Deserializing untrusted input (`JSON.parse` is fine; YAML/pickle/`unserialize`
  with untrusted data is not).
- Missing input validation at the trust boundary - no schema, no length cap.
- SSRF: fetching a user-supplied URL without an allowlist.
- Open redirect: redirecting to a user-supplied location.

## Crypto and transport

- `Math.random()` for tokens, IDs or salts -> `crypto.randomBytes`.
- MD5/SHA-1 for passwords or signatures -> bcrypt/argon2 for passwords.
- TLS verification disabled (`rejectUnauthorized: false`).

## Reporting

Report severity by exploitability, and name the attacker's path in one clause:
"any authenticated user can read every other user's invoices by changing the id
in the URL."
